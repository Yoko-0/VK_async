from random import randint

def get_random_id():
    return randint(1, 10000000)
